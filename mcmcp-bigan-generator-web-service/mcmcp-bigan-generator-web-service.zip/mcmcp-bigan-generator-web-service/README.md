# mcmcp-bigan-generator
just the generator code for a pretrained BiGAN, for use with MCMCP experiments

to run, just run generate.py

requirements: numpy, scipy, scikit-learn==0.18.1 (at least), theano
